import { ApiExtensionContext } from '@directus/types';

export type Logger = ApiExtensionContext['logger'];
