export enum ErrorCode {
	Forbidden = 'FORBIDDEN',
	InvalidPayload = 'INVALID_PAYLOAD',
}
