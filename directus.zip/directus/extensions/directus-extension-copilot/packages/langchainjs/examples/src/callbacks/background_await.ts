import { awaitAllCallbacks } from "langchain/callbacks";

await awaitAllCallbacks();
