import { awaitAllCallbacks } from "../src/callbacks/promises.js";

afterAll(awaitAllCallbacks);
