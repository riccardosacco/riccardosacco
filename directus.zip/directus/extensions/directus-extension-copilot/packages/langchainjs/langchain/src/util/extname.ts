export const extname = (path: string) => `.${path.split(".").pop()}`;
