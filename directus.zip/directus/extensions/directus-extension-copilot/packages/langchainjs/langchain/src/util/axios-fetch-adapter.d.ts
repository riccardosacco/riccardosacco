// eslint-disable-next-line import/no-extraneous-dependencies
import { AxiosRequestConfig, AxiosPromise } from "axios";

export default function fetchAdapter(config: AxiosRequestConfig): AxiosPromise;
