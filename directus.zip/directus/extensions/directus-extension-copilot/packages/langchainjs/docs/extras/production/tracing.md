# Tracing

Similar to the Python `langchain` package, JS `langchain` also supports tracing.

You can view the tracing docs, including the JS Quickstart [here.](https://docs.smith.langchain.com/docs/)
